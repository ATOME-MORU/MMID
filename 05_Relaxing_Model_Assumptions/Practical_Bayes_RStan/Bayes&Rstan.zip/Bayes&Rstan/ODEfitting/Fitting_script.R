#Model fitting based on SIR   
#R script to call Rstan to do model fitting 

rm(list = ls())
# setwd("C:/...") #a easy way by band: Session->Set Working direction->To source file location
rstan_options (auto_write = TRUE)
options (mc.cores = parallel::detectCores ())

library(rstan)
library(bayesplot)
library(ggplot2)

inc_data <- read.csv('simdat0.csv')         #upload simulation data to do model fitting
cases<-round(inc_data[-1,2])                #round incidence data into integer

N<-50000000
n_days<-length(cases)
t<-seq(0,1,by= 1/52)
t0=0
t<-t[-1]

######################Model fitting################
#--------------------SIR------------# 

data_sir <- list( n_days=n_days,
                  t0=t0,
                  ts=t,
                  cases=cases,
                  N = N)

niter <- 2000
chains<-4

model_pred_SIR<-stan("SIR_model_3.stan",
                     data = data_sir,
                     iter = niter,
                     chains = chains)
print(model_pred_SIR)

#Checking stan outputs
beta_pred<-rstan::extract(model_pred_SIR)$beta
nu_pred<-rstan::extract(model_pred_SIR)$nu
i0_pred<-rstan::extract(model_pred_SIR)$i0
mu_pred<-rstan::extract(model_pred_SIR)$mu
report_pred<-rstan::extract(model_pred_SIR)$report

# hist(beta_pred)
mcmc_areas(model_pred_SIR,pars = "beta",prob = 0.95)    #95% credible interval 
mcmc_areas(model_pred_SIR,pars = "nu",prob = 0.95)     
mcmc_areas(model_pred_SIR,pars = "i0",prob = 0.95)      
mcmc_areas(model_pred_SIR,pars = "mu",prob = 0.95)      
mcmc_areas(model_pred_SIR,pars = "report",prob = 0.95)      


#diagnostic plots
traceplot(model_pred_SIR, pars = c( "beta","nu","i0","report","mu"))
stan_dens(model_pred_SIR, pars =  c( "beta","nu","i0","report","mu"), separate_chains = TRUE)

#Plot fitting results
pred_cases_SIR<-rstan::extract(model_pred_SIR)$pred_cases
# pred_cases_median<-apply(pred_cases_SIR, 2, median)
# pred_cases_low<-apply(pred_cases_SIR,2, function(x) quantile(x,probs=0.25))
# pred_cases_upp<-apply(pred_cases_SIR,2,function(x) quantile(x,probs=0.75))
# plot(pred_cases_upp,type="l",col="red")
# lines(pred_cases_median)
# lines(pred_cases_low,col="red")
# points(cases)

#ggplot
t_start <- 0
t_stop <- 1
times <- seq(t_start, t_stop, by = 1/52)[-1]

data<-data.frame(week=times,
                 pred_median=apply(pred_cases_SIR, 2, median),
                 pred_low=apply(pred_cases_SIR,2, function(x) quantile(x,probs=0.025)),
                 pred_upp=apply(pred_cases_SIR,2,function(x) quantile(x,probs=0.975)),
                 obs_cases=cases)
ggplot(data, aes(x=week, y = pred_median)) +
  geom_line(size = 0.5,color= "#00A5CF") +   
  geom_ribbon(aes(ymin=pred_low, ymax=pred_upp), alpha=0.2, colour = NA,fill="#00A5CF")+
  geom_point( aes(week, obs_cases),color="#574AE2",size=1)+
  ylab("incidence") +
  xlab(" time")+
  ggtitle("Model fitting based on SIR")
