# CDT Health Data Science

####################################################
## SIMULATED DATA GENERATION FOR PRACTICAL SESSION## 
####################################################

# set your working directory: Session, Set Working Directory, To Source File Location
# setwd("...")

library(deSolve)

t_start <- 0
t_stop <- 1
times <- seq(t_start, t_stop, by = 1/52)

#MODEL PARAMETERS
parameters <- c(mu=(1/(50)),    # birth/death rate = 1/(life expectancy)
                beta=32,        # transmission coefficient
                nu=1/(3/52),    # rate of recovery = 1/(average duration of infection)
                omega =0,       # 1/(duration of immunity)
                report=1/10,    # proportion of all infections that are reported
                amp=0,          # relative amplitude of seasonal forcing
                phi=0           # month of peak in seasonal forcing
)

# MODEL INITIAL CONDITIONS
initP<-50000000 # population size

initI<-100 # Infectious
initR<-0 # Immune
initS<-initP-initI-initR # Susceptible (non-immune)

state <- c(S = initS, I = initI,R = initR, C = 0)

# set up a function to solve the equations
SIRSmodel<-function(t, state, parameters) 
{
  with(as.list(c(state, parameters)),
       {
         
         # define variables
         P <- (S+I+R)
         seas<-1+amp*cos(2*pi*(t-phi/12))
         lambda <- beta*seas*I/P
         
         # rate of change
         dS <- mu*P-mu*S-lambda*S+omega*R
         dI <- -mu*I+lambda*S-nu*I
         dR <- -mu*R+nu*I-omega*R
         
         dC <- lambda*S
         
         # return the rate of change
         list(c(dS, dI, dR, dC))
       }
  ) 
  
}

####################################################
# run the model for SIR-style parameter set
####################################################

out <- ode(y = state, times = times, func = SIRSmodel, parms = parameters)

# some more model outputs
# total population
pop<-out[,"S"]+out[,"I"]+out[,"R"]
time<-out[,"time"]
# weekly incidence
inc <- 0*time
inc[2:length(time)]<-parameters["report"]*(out[2:length(time),"C"]-out[1:(length(time)-1),"C"])


# generate simulated data
# incdat1 <-round(rnorm(length(inc), mean = inc, sd = relerr*inc))
incdat1<-rnbinom(rep(1,length(times)), size= 200, mu=inc) #generate data from negative binomial process

# COMPARING THE MODEL OUTPUT WITH DATA
par(mfrow=c(1,3))
yl <- c(0,max(incdat1,inc))
plot(time,inc,type='l',lwd=3,main = "Incidence",xlab = "Time in years",ylab="New reported cases per week",ylim=yl,col='grey')
points(time,incdat1,pch=19,col='black')


parameters["beta"]/(parameters["nu"]+parameters["mu"])
x <- matrix(0,nrow=length(time),ncol=2)
x[,1]<-time
x[,2]<-incdat1
# create data file
write.csv(x, file = "simdat0.csv", row.names = FALSE)



