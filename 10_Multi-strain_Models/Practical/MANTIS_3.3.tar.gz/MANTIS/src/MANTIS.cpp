#include <Rcpp.h>
#include <math.h>
#include <stdio.h>
using namespace Rcpp;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

//to test this file directly in R:
//require(Rcpp)
//sourceCpp("MANTIS/src/MANTIS.cpp")
//source("MANTIS/R/MANTIS.R")
//run desired R code

//http://stackoverflow.com/questions/184537/in-what-cases-do-i-use-malloc-vs-new

//define structures here
struct HKEEP{
  int nStrains;
  int nShep;
  int nEqs;
  double totVirus;
  IntegerVector sharedEpitopes;
  NumericVector sumSharedLambda;
  NumericVector lambda;
};

struct PARAM{
  NumericVector beta;
  double gamma;
  double mu;
  double sigma;
  double epsilon;
  double omega;
};

//define extra functions here
void requiredSums(double *, struct HKEEP *, struct PARAM *,double t);
double inline seasonBeta(double t,double b,double epsilon);
void ddt(NumericVector, NumericVector, struct HKEEP *, struct PARAM *);
void rkck(NumericVector, NumericVector, double, struct HKEEP *, struct PARAM *);

//define derivatives here
double dzdt(double, double, double, double, int, struct HKEEP *);
// double dzdt(double, double, int, struct HKEEP *);
double dwdt(double, double, int, struct HKEEP *);
double dydt(double, double, double, double, double, double, int, struct HKEEP *);

//this is the function whose result we want to export
// [[Rcpp::export]]
Rcpp::List Rcpp_LociEpitope(int nStrains, int nEqs, int nShep, IntegerVector sharedEpitopes, 
                                NumericVector initCondY, 
                                double tMax, double obsInt, double tInt,
                                NumericVector beta, double gamma, double mu, double sigma, double epsilon, double omega,
                                NumericVector initCondZ, NumericVector initCondW)
{ 
  //additional variable declaration
  struct PARAM p; // name of a structure where parameter values are kept [that need to be referenced by multiple functions]
  struct HKEEP h; //name of a structure where housekeeping values are kept [that need to be referenced by multiple functions]
  int n_req_obs = floor(tMax/obsInt) + 1; //required length of 't' {time} vector and 'y' {output} matrix
  
  double t = 0.0; //starting time
  int timestep = 0; //tracks location of next position to write to in 't' and 'y' 
  
  NumericVector x(nEqs), dxdt(nEqs); //vectors to carry current state and derivatives around in
  double *Y; //pointers to values in current state
  double *Z; //pointers to values in current state
  double *W; //pointers to values in current state
  
  int progper= int(tMax/tInt/5); //period to output X points in computational progress
  int progstep= 0;

  //pre-allocate size of outputs
  NumericVector tArray(n_req_obs); //preallocating 't' {time}
  NumericMatrix yArray(n_req_obs,nEqs); //preallocating 'y' {output}
  
  //assign parameter values to 'p'
  p.beta = beta; 
  p.gamma = gamma;
  p.mu = mu;
  p.sigma = sigma;
  p.epsilon = epsilon;
  p.omega= omega;
  
  //assign housekeeping values to 'h'    
  h.nStrains = nStrains; //number of strains
  h.nShep = nShep; //number of strains with which you share epitopes [including yourself]
  h.nEqs = nEqs; //total number of equations
  h.totVirus = 0; //total amount of virus
  h.sharedEpitopes = sharedEpitopes; //shared epitope matrix 
  h.sumSharedLambda = NumericVector(h.nStrains); //sum of virus that shares epitopes with each strain [i.e. force of infection for each virus in w equation]
  h.lambda = NumericVector(h.nStrains); //force of infection for each virus in z equation

  //set up pointer to Y class
  Z = &x[0]; //pointer to first equation for specific immunity
  W = &x[nStrains]; //pointer to first equation for cross-reactive immunity
  Y = &x[2*nStrains]; //pointer to first equation for proportion  of population infected with each strain

  //set up intial conditions
  for(int i=0; i < h.nStrains; i++){
  			Y[i] = initCondY(i); //then update the Ys as desired
  			Z[i] = initCondZ(i); //then update the Ys as desired
  			W[i] = initCondW(i); //then update the Ys as desired
  	}
  
  //record intial state 
  tArray(timestep) = t; //record starting time
  for(int i=0; i < nEqs; i++){
  		yArray(timestep,i) = x(i); //record intial conditions
  }
  timestep ++; //move observation marker to next desired time

  Rcpp::Rcout << "omega: "<< p.omega << std::endl;

  progstep= 0;
  do{
    t += tInt; // increment time
    //use timestep (obs) to give a proxy of computing progress
    if((progstep % progper)==0) Rcpp::Rcout << "[ at "<< round(100*t/tMax) <<"% ]" << std::endl;
    requiredSums(Y,&h,&p,t); //do the necessary sums for this timestep
    ddt(x,dxdt,&h,&p); //calculate the derivatives
    rkck(x,dxdt,tInt,&h,&p);
    //if appropriate, record current state
    if(t >= timestep*obsInt){ //if have reached/passed next observation point, then record results ...
      tArray(timestep) = t;
      for(int i=0; i < nEqs; i++) yArray(timestep,i) = x(i);
      timestep ++; //...and move marker post on to next desired position
    }
    progstep++;
  }while(t<=tMax);
  
  Rcpp::List res =
    Rcpp::List::create(Rcpp::Named("T")=tArray,
                         Rcpp::Named("Y")=yArray);                       
  return res;
}

void requiredSums(double *Y,struct HKEEP *h, struct PARAM *p, double t)
{ 
  int nStrains = h->nStrains, nShep = h->nShep;
  double betai;

  //reset sums to zero
  h->totVirus = 0;
  for(int i=0; i<nStrains; i++){
    h->lambda(i) = 0;
    h->sumSharedLambda(i) = 0;
  }
  
  //calculate new sums
  for(int i=0; i<nStrains; i++){
    betai= seasonBeta(t, p->beta[i], p->epsilon); //address seasonality in beta
    h->totVirus += Y[i]; //totalVirus
    h->lambda(i) = betai*Y[i]; //force of infection in z equations
    for(int j=0; j<nShep; j++){
      int a = h->sharedEpitopes(i,j);
      h->sumSharedLambda(i) += betai*Y[a]; //amount of virus to prime cross-reactive antibody response
    }
  }
}

double inline seasonBeta(double t, double b, double epsilon){
  return( b*(1.0+epsilon*pow(sin(M_PI*t),6)) );
}


void ddt(NumericVector x, NumericVector dxdt, struct HKEEP *h, struct PARAM *p)
{
  int nStrains = h->nStrains;
  double *Z, *W, *Y; //pointers to values in current state
  double *dev_Z, *dev_W, *dev_Y; //pointers to derivatives in current state
  
  Z = &x[0]; //pointer to first equation for specific immunity
  W = &x[nStrains]; //pointer to first equation for cross-reactive immunity
  Y = &x[2*nStrains]; //pointer to first equation for virus 
  
  dev_Z = &dxdt[0]; //pointer to first equation for specific immunity
  dev_W = &dxdt[nStrains]; //pointer to first equation for cross-reactive immunity
  dev_Y = &dxdt[2*nStrains]; //pointer to first equation for virus
  
  for(int i=0; i<nStrains; i++){
    dev_Z[i] = dzdt(Z[i],W[i],p->mu,p->omega,i,h);
    dev_W[i] = dwdt(W[i],p->mu,i,h);
    dev_Y[i] = dydt(Y[i],Z[i],W[i],p->gamma,p->sigma,p->mu,i,h);
  }
}

// //these are the definitions of the derivatives 
// double dzdt(double z,double mu, int strain,struct HKEEP *h)//need to correct[all of these] for when we work out where lambda is going
// {
//     return  (1 - z)*h->lambda(strain) - mu*z;
// }//e.g. dz1dt = (1-z1)*lambda1 - mu*z1

//these are the definitions of the derivatives 
double dzdt(double z, double w, double mu, double omega, int strain,struct HKEEP *h)//need to correct[all of these] for when we work out where lambda is going
{
    return  ((1.0-w)+(1.0-omega)*(w-z))*h->lambda(strain) - mu*z;
}

double dwdt(double w,double mu,int strain, struct HKEEP *h)
{
    return (1.0 - w)*h->sumSharedLambda(strain) - mu*w;
}

double dydt(double y, double z, double w, double gamma, double sigma, double mu, int strain, struct HKEEP *h)
{
    return ((1.0 - w) + (1.0 - gamma)*(w - z))*h->lambda(strain) - sigma*y - mu*y;
}

// range-kutta solver
void rkck(NumericVector y, NumericVector dydt, double s, struct HKEEP *h, struct PARAM *p)
{
  int nEqs = h->nEqs;
  //double *k2, *k3, *k4, *k5, *k6, *ytemp;
  static double b21=0.2,b31=3.0/40.0,b32=9.0/40.0,b41=0.3,b42=-0.9,b43=1.2,
      b51=-11.0/54.0,b52=2.5,b53=-70.0/27.0,b54=35.0/27.0,b61=1631.0/55296,
		  b62=175.0/512.0,b63=575.0/13824.0,b64=44275.0/110592,b65=253.0/4096.0,
		  c1=37.0/378.0,c3=250.0/621.0,c4=125.0/594.0,c6=512.0/1771.0;
      
  NumericVector k2(nEqs);
  NumericVector k3(nEqs);
  NumericVector k4(nEqs);
  NumericVector k5(nEqs);
  NumericVector k6(nEqs);
  NumericVector ytemp(nEqs);
	
	for(int i = 0; i<nEqs; i++)
		ytemp[i]= y[i]+b21*s*dydt[i];
	ddt(ytemp,k2,h,p);
	
	for(int i = 0; i<nEqs; i++)
		ytemp[i]= y[i]+s*(b31*dydt[i]+b32*k2[i]);
	ddt(ytemp,k3,h,p);
	
	for(int i = 0; i<nEqs; i++) 
		ytemp[i]= y[i]+s*(b41*dydt[i]+b42*k2[i]+b43*k3[i]);
	ddt(ytemp,k4,h,p);
	
	for(int i = 0; i<nEqs; i++) 
		ytemp[i]= y[i]+s*(b51*dydt[i]+b52*k2[i]+b53*k3[i]+b54*k4[i]);
	ddt(ytemp,k5,h,p);
	
	for(int i = 0; i<nEqs; i++) 
		ytemp[i]= y[i]+s*(b61*dydt[i]+b62*k2[i]+b63*k3[i]+b64*k4[i]+b65*k5[i]);
	ddt(ytemp,k6,h,p);

	for(int i = 0; i<nEqs; i++) 
		y[i]= y[i]+s*(c1*dydt[i]+c3*k3[i]+c4*k4[i]+c6*k6[i]);
   
}
