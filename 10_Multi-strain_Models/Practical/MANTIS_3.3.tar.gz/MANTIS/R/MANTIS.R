
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#### FUNCTIONS AVAILABLE ON MANTIS V1.0. (STARTCODE_V1.0)
#### THERE MAY HAVE BEEN CHANGES, UPDATES OR BUG CORRECTIONS.

#' Run the Multilocus ANTIgenic Simulator (MANTIS)
#' 
#' Function that runs the multilocus model. A deterministic ordinary-differential equations system (ODE) is solved. For more
#' details on the conceptual framework, including variables and biological parameters, a summary can be found in the 
#' manual. References to the literature can also be found by running the function \code{readingMANTIS()}. 
#' 
#' @param epiStruc desired antigenic structure for the simulation. It should be an array of integers specifying the number of alleles per locus. Its length determines the number of loci and each integer the number of alleles per locus. The minimum number of loci allowed is 2 (\code{length(epiStruc)>=2}) and therefore the minimum number of strains in the system is also 2. If the user wants to simulate 2 strains, the second locus can be set to have only one allele, that is \code{epiStruct=c(2,1)}.
#' @param tMax the time at which the solver will stop solving the ODE system.
#' @param tObsPer an integer specifying the periodicity at which the solution is recorded. It may be used to reduce the size of the output variable considerably.
#' @param tStep time step for the fixed-step ODE solver. If the dynamics of the system appear inconsistent, this should be reduced.
#' @param initCondY initial conditions for the infectious classes (\code{Yi}). This is a collection of numbers of length equal to the number of strains in the system. Its sum needs to be smaller than 1, as initial conditions represent proportions.
#' @param beta numeric value or collection of numbers. If a single value is given, all strains will share beta=value. If a collection of numbers is given, it is required that the length of the collection be equal to the number of strains; in this case each strain indexes the collection and can have a different value for beta.
#' @param gamma number representing cross-protection given by challenge of strains that share alleles. This needs to be between 0 and 1 (inclusive), for which 0 confers no protection and 1 full protection.
#' @param sigma number representing the recovery rate (also known as the loss of infection rate). \code{1/sigma} is the infectious period.
#' @param mu number representing the death rate of all individuals in the system. \code{1/mu} is the mean life-span.
#' @param epsilon number representing the strength of seasonality changes in \code{beta}, defaults to zero. \code{epsilon=0} equates to 
#' no seasonality changes. If \code{epsilon>0}, \code{beta} suffers from yearly seasonal changes. Seasonality is modelled via 
#' a sinusoidal signal, defined as \code{beta*(1.0+epsilon*pow(sin(PI*t),6))}. This means that \code{beta} is the minimum (out of season)
#' and \code{beta*(1+epsilon)} the peak of the season. NOTE: seasonality expects model parameters to be defined per year, as modelled
#' oscillations are per year. Seasonality parameters can be tested using the function \code{testSeasonality}, see ?testSeasonality.
#' @param omega experimental parameter for OAS. This needs to be between 0 and 1 (inclusive), for which 0 confers full OAS response and 1 no OAS response.
#' @param initCondZ initial conditions for the infectious classes (\code{Zi}). This is a collection of numbers of length equal to the number of strains in the system. Its sum needs to be smaller than 1, as initial conditions represent proportions. This is optional and will be assumed zero if not given.
#' @param initCondW initial conditions for the infectious classes (\code{Wi}). This is a collection of numbers of length equal to the number of strains in the system. Its sum needs to be smaller than 1, as initial conditions represent proportions. This is optional and will be assumed zero if not given.
#' @return A 'list' of size 4.  The first element is 'time'; the second element is the resulting 'time series'; the third element 
#' contains the information about 'shared epitopes' between strains; and the fourth element contains the 'allelic matrix' which describes
#' the allelic combination that defines each strain in the system.
#' 
#' 'time' is an array of numbers representing the time steps of the simulation's solution, its length is determined by \code{tMax/tStep}. 
#' 
#' 'time series' is a matrix with \code{tMax/tStep} rows and \code{3*nStrains} columns (nStrains is the number of strains). Each column of 'time series'
#' represents an epidemiological class (equation) in the system. Columns \code{1}:\code{nStrains} are the classes \code{Zi} for each \code{strain i},  
#' representing individuals with specific-immunity to \code{strain i}. Columns \code{(nStrains+1)}:\code{(nStrains*2)} are the classes \code{Wi}
#' for each \code{strain i}, representing cross-reactive individuals to \code{strain i}. Columns \code{(nStrains*2+1):(nStrains*3)} are 
#' the classes \code{Yi} for each \code{strain i}, representing infectious individuals with \code{strain i}. For more details on the epidemiological
#' framework, including variables \code{Z, W, Y} and biological parameters, see references in the output of function \code{readingMANTIS() }.
#' 
#' 'shared epitopes' is a matrix with N rows and M columns. N equals the number of strains and M the number of possible strains to which each strain
#' can share an allele. Each row \code{i} contains a set of integer numbers identifying which other strains share an allele with strain \code{i}.
#' For example, for an antigenic structure \code{epiStruct=c(2,2)}, giving 4 strains, 'shared epitopes' will have 4 rows in which the first will contain 
#' \code{"1 2 3"}, meaning that strain 1 shares alleles with strain 1, 2 and 3.
#'
#' 'allelic matrix' is a matrix with N rows and L columns. N equals the number of strains and L the number of loci. For simplification, alleles
#' are defined by integer numbers from \code{1....Al}, with \code{Al} being the maximum diversity allowed at each loci \code{l}. Each row represents
#' the combination of alleles that define each strain. 
runMANTIS <- function(epiStruc, tMax, tObsPer, tStep, initCondY, beta, gamma, sigma, mu, omega=0, epsilon=0, initCondZ=NA, initCondW=NA){

  ## checks on parameter types and values

  if(length(epiStruc)==0 | length(which(epiStruc<0))>0){
    stop("epiStruc has to be a 'collection' of integers bigger than zero. See '?runMANTIS")
  }

  if(length(epiStruc)==1){
    stop("the number of loci needs to be bigger or equal to 2. See '?runMANTIS")
  }  


  n.loci <- length(epiStruc)
  # work out how strains are related & build shared epitope matrix
  # strainmx contains the actual allelic "sequences" of each strain
  strainmx <- as.data.frame(expand.grid(lapply(epiStruc,seq,from=1,by=1)))
  nStrains <- dim(strainmx)[1]
  
  colnames(strainmx)<- paste("locus",1:n.loci,sep="")	
  rownames(strainmx)<- NULL
  #rownames(strainmx)<- paste("strain",1:nStrains,sep="")	

  if(!is.numeric(tMax) | tMax<0){
    stop("tMax has to be a number bigger than zero. See '?runMANTIS")
  }  

  if((tObsPer %% 1)!=0 | tObsPer<1){
    stop("tObsPer should be an integer bigger than 1. See '?runMANTIS")
  } 

  if(!is.numeric(tStep) | tStep<0){
    stop("tStep has to be a number bigger than zero. See '?runMANTIS")
  }  

  if(length(initCondY)==0 | length(which(initCondY<0))>0 | sum(initCondY)>1 | length(initCondY)!=nStrains){
    stop("initCondY has to be a 'collection' of positive numbers adding to <1, with length equal to the number of strains. See '?runMANTIS")
  }

  for(bb in beta){
	if(!is.numeric(bb) | bb<0)
		stop("beta has to be a number bigger or equal to zero. See '?runMANTIS")
  }  

  if(!is.numeric(gamma) | gamma<0 | gamma>1){
    stop("gamma has to be a number between zero and one. See '?runMANTIS")
  }

  if(!is.numeric(omega) | omega<0 | omega>1){
    stop("omega has to be a number between zero and one. See '?runMANTIS")
  }

  if(!is.numeric(epsilon) | epsilon<0){
    stop("epsilon has to be a number bigger or equal to zero. See '?runMANTIS")
  }  

  if(!is.numeric(sigma) | sigma<0){
    stop("sigma has to be a number bigger than zero. See '?runMANTIS")
  }

  if(!is.numeric(mu) | mu<0){
    stop("mu has to be a number bigger than zero. See '?runMANTIS")
  }
  
  if(length(beta)!=1 & length(beta)!=nStrains){
	 stop("beta has to be a number (in which case all strains have the same beta) or a numeric array of length nStrains. See '?runMANTIS")
  }

  #take care of the initial conditions of all variables (Z)
  if(sum(is.na(initCondZ))!=0){
    #none were given, so assume all to zero
    initCondZ= rep(0,nStrains)
  }else{
    if(sum(!is.numeric(initCondZ))>0 | length(initCondZ)!=nStrains){
      stop("initCondZ must be of the length of the number of equations in the system, and must be numeric. One of these rules was broken. See '?runMANTIS")
    }
  }

  #take care of the initial conditions of all variables (W)
  if(sum(is.na(initCondW))!=0){
    #none were given, so assume all to zero
    initCondW= rep(0,nStrains)
  }else{
    if(sum(!is.numeric(initCondW))>0 | length(initCondW)!=nStrains){
      stop("initCondW must be of the length of the number of equations in the system, and must be numeric. One of these rules was broken. See '?runMANTIS")
    }
  }  
  
  #if given one value, expand to nstrains (all betas the same)
  if(length(beta)==1){
	   beta= rep(beta, nStrains)
  }

  for(i in 1:nStrains){
    temp <- which(strainmx[,1] == strainmx[i,1])
    for(j in 2:n.loci){
      temp <- union(temp,which(strainmx[,j] == strainmx[i,j]))
    }
    switch(i == 1,sharedEpitopes <- array(0,c(nStrains,length(temp))))
    sharedEpitopes[i,] <- sort(temp)
  }
  sharedEpitopes.to.send <- sharedEpitopes - 1 # remember! C indexing is different to R; C starts from 0
  nShep = dim(sharedEpitopes)[2]
  rm(i,j,temp)
   
  # number of equations 
  nEqs <- 3*nStrains  

  #observing time range
  tObsStep<- tObsPer*tStep

  cat("Running MANTIS, please wait...\n")
  X<- Rcpp_LociEpitope(nStrains, nEqs, nShep, sharedEpitopes.to.send, initCondY, tMax, tObsStep, tStep, beta, gamma, mu, sigma, epsilon, omega, initCondZ, initCondW)
  X<- c(X, list(sharedEpitopes), list(strainmx))

  return (X)
}

#' Print a welcome message.
#'
#' Print a welcome message from the Multilocus ANTIgenic Simulator (MANTIS) team.
#' 
helloMANTIS <- function(){
  cat("Hello world!\n\n We hope you enjoy using our *M*ultilocus *ANTI*genic *S*imulator.\n")
  cat("Please don't forget to reference this package on your own research publications. Thank you for your support!\n\n")
}


#' Test Seasonality.
#'
#' Can be used to test parameters for seasonal forcing in transmission.
#' See ?runMANTIS for details on seasonality, beta and epsilon.
#'
#' @param epsilon the strenght of the seasonal signal.
#' @param beta the (minimum) beta for transmission.
#' @param time time vector for the test, defaults to 50 years.
#'
testSeasonality <- function(epsilon, beta, time=seq(1,50,0.025)){

  signal<-function(beta, epsilon, t){
    return(beta*(1.0+epsilon*(sin(PI*t)^6)))
  }

  PI<- 3.14159265358979323846
  
  plot(time,signal(beta,epsilon,time),t='l',xlab="time in years",ylab="beta",main="testing seasonality",ylim=c(beta*0.9,beta*(1+epsilon)*1.1))
  abline(h=beta,col="grey",lty=2)
  box(lwd=1.5)
}


#' Print a list of reading suggestions by the Multilocus ANTIgenic Simulator (MANTIS) team.
#' 
#' This function prints a list of the recommended literature on the epidemiological framework behind MANTIS.
#' 
readingMANTIS <- function(){
  cat("\nHello user.\n\nWe hope you enjoy using our *M*ultilocus *ANTI*genic *S*imulator (MANTIS). If you are looking for information on the epidemiological framework behind MANTIS, please have a look at the following material:\n")
  cat("\n")
  cat("(1) Chaos, persistence, and evolution of strain structure in antigenically diverse infectious agents. Gupta S, Ferguson N, Anderson R. Science. 1998 May 8;280(5365):912-5.\n\n")
  cat("(2) The antigenic evolution of influenza: drift or thrift? Wikramaratna PS, Sandeman M, Recker M, Gupta S. Philos Trans R Soc Lond B Biol Sci. 2013 Feb 4;368(1614):20120200.\n\n")
  cat("(3) Transient cross-reactive immune responses can orchestrate antigenic variation in malaria. Recker M, Nee S, Bull PC, Kinyanjui S, Marsh K, Newbold C, Gupta S. Nature. 2004 Jun 3;429(6991):555-8.\n\n")
  cat("(4) Role of stochastic processes in maintaining discrete strain structure in antigenically diverse pathogen populations. Buckee CO, Recker M, Watkins ER, Gupta S. Proc Natl Acad Sci U S A. 2011 Sep 13;108(37):15504-9.\n\n")
  cat("(5) The generation of influenza outbreaks by a network of host immune responses against a limited set of antigenic types. Recker M, Pybus OG, Nee S, Gupta S. Proc Natl Acad Sci U S A. 2007 104, 7711-7716.\n\n")
}

#' Get the number of possible strains.
#' 
#' Returns the number of strains that will exist in a system with antigenic structure 'epiStruc'.
#' 
#' @param epiStruc the antigenic structure of the system. See \code{?runMANTIS} for details.
#' @return an integer number of strains in the system as defined by 'epiStruc'
extractNumberStrains <- function(epiStruc){

  if(length(epiStruc)==0  | length(which(epiStruc<0))>0){
    stop("epiStruc has to be a 'collection' of integers bigger than zero. See '?runMANTIS")
  }

  #work out how many strains the system has
  strainmx <- expand.grid(lapply(epiStruc,seq,from=1,by=1))
  return(dim(strainmx)[1])
}



#' Export the simulated time-series.
#' 
#' Creates a comma separated CSV text file in which the columns are the solution of the simulation. First column is time
#' and the remaining columns are, in order, classes Z, W and Y. 
#' See the definition of 'time series' in \code{?runMANTIS}.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param fileout the name of the output CSV file.
exportTS <- function(data, fileout="default.filename.csv"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportTS")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportTS")
  }

  time.series<- data[[1]]
  class.series<- data[[2]]
  nStrains<- ncol(class.series)/3
  strainsIDs= 1:nStrains
  columnNames<- c("time", paste("Z",strainsIDs,sep=""), paste("W",strainsIDs,sep=""), paste("Y",strainsIDs,sep=""))

  dataOut<- data.frame(time.series, class.series)
  colnames(dataOut)= columnNames

  .writeCSVTS(dataOut, fileout)

}

#' Export the infectious (Y) classes in terms of relative prevalence.
#' 
#' Creates a comma separated CSV text file in which the columns are the relative prevalence of each strain in the 
#' infectious (Y) classes. First column is time and the remaining columns are the relative prevalences (between 0 and 1)
#' calculated by dividing each strain's prevalence by the total pathogen prevalence. 
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param fileout the name of the output CSV file.
#' @param method a character string to choose the method to be used for the estimation of the pathogen's total prevalence. Methods are \code{"host"} and \code{"strain"} and relate to how total 
#' prevalence of the pathogen is estimated. When \code{method="host"} the function \code{extractPathogenPrevByStrain} is called and when \code{method="strain"} 
#' the function \code{extractPathogenPrevByHost} is called. See the help of each function for how they differ. Estimations are expected to be very similar using the two methods.
#' 
exportYRelPrevalence <- function(data, fileout="default.filename.csv", method="host"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportYRelPrevalence")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportYRelPrevalence")
  }

  time.series<- data[[1]]
  Yr<- extractYRelPrevalences(data, method)
  nStrains<- ncol(data)/3
  strainsIDs= 1:nStrains

  columnNames<- c("time", paste("Y",strainsIDs,sep=""))
  dataOut<- data.frame(time.series, Yr)
  colnames(dataOut)= columnNames

  .writeCSVTS(dataOut, fileout)

}

#' Export the simulated time-series' diversity of the infectious (Y) classes.
#' 
#' Creates a comma separated CSV text file in which the columns are the solution of the simulation in diversity 
#' measures for infectious (Y) classes. First column is time and the second and third column are the default 
#' diversity measures. See ?calcDiversity for details on the measures.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param xiObs the starting proportion of time to use for diversity. For example \code{xiObs=0.5} will start from the middle of the time-series.
#' @param xfObs the end proportion of time to use for diversity.
#' @param fileout the name of the output CSV file.
#' 
exportYDiversity <- function(data, xiObs=0.5, xfObs=1.0, fileout="default.filename.csv"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportTSDiversity")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportTSDiversity")
  }

  divSh<- calcDiversity(extractY(data), xiObs=xiObs, xfObs=xfObs, method="shannon")
  divSi<- calcDiversity(extractY(data), xiObs=xiObs, xfObs=xfObs, method="simpson")
  
  time.series<- data[[1]]
  rr<- (xiObs*length(time.series)):(xfObs*length(time.series))
  time.series<- data[[1]][rr]
  columnNames<- c("time", "shannon", "simpson")
  dataOut<- data.frame(time.series, divSh, divSi)
  colnames(dataOut)= columnNames

  .writeCSVTS(dataOut, fileout)

}

#' Export the simulated time-series' diversity of the specific-immunity (Z) classes.
#' 
#' Creates a comma separated CSV text file in which the columns are the solution of the simulation in diversity
#' measures for specific-immunity classes (Z). First column is time and the second and third column are the default 
#' diversity measures. See ?calcDiversity for details on the measures.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param xiObs the starting proportion of time to use for diversity. For example \code{xiObs=0.5} will start from the middle of the time-series.
#' @param xfObs the end proportion of time to use for diversity.
#' @param fileout the name of the output CSV file.
#'
exportZDiversity <- function(data, xiObs=0.5, xfObs=1.0, fileout="default.filename.csv"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportTSDiversity")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportTSDiversity")
  }

  divSh<- calcDiversity(extractZ(data), xiObs=xiObs, xfObs=xfObs, method="shannon")
  divSi<- calcDiversity(extractZ(data), xiObs=xiObs, xfObs=xfObs, method="simpson")

  time.series<- data[[1]]
  rr<- (xiObs*length(time.series)):(xfObs*length(time.series))
  time.series<- data[[1]][rr]
  columnNames<- c("time", "shannon", "simpson")
  dataOut<- data.frame(time.series, divSh, divSi)
  colnames(dataOut)= columnNames

  .writeCSVTS(dataOut, fileout)

}

#' Export the simulated time-series' diversity of the cross-reactive (W) classes.
#' 
#' Creates a comma separated CSV text file in which the columns are the solution of the simulation in diversity 
#' measures for cross-reactive (W) classes. First column is time and the second and third column are the default
#' diversity measures. See ?calcDiversity for details on the measures.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param xiObs the starting proportion of time to use for diversity. For example \code{xiObs=0.5} will start from the middle of the time-series.
#' @param xfObs the end proportion of time to use for diversity.
#' @param fileout the name of the output CSV file.
#'
exportWDiversity <- function(data, xiObs=0.5, xfObs=1.0, fileout="default.filename.csv"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportTSDiversity")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportTSDiversity")
  }

  divSh<- calcDiversity(extractW(data), xiObs=xiObs, xfObs=xfObs, method="shannon")
  divSi<- calcDiversity(extractW(data), xiObs=xiObs, xfObs=xfObs, method="simpson")

  time.series<- data[[1]]
  rr<- (xiObs*length(time.series)):(xfObs*length(time.series))
  time.series<- data[[1]][rr]
  columnNames<- c("time", "shannon", "simpson")
  dataOut<- data.frame(time.series, divSh, divSi)
  colnames(dataOut)= columnNames

  .writeCSVTS(dataOut, fileout)

}


#' Export the epitope relationships between strains.
#' 
#' Creates a comma separated CSV text file in which each row correspondes to an existing strain. Each row \code{i} contains a set of integers 
#' which identify which other strains share epitopes with strain \code{i}. See the definition of 'shared epitopes' in \code{?runMANTIS}.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param fileout the name of the output CSV file.
exportSharedEpitopes <- function(data, fileout="default.filename.csv"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportSharedEpitopes")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportSharedEpitopes")
  }

  nStrains<- ncol(data[[2]])/3
  strainsIDs<- 1:nStrains
  rowNames<- paste("strain",strainsIDs,sep="")

  dataOut<- data.frame(withSharedEpitopes(data))
  rownames(dataOut)= rowNames

  .writeCSVTS(dataOut, fileout)

}


#' Plot the infectious (Y) time-series of all strains in the system.
#' 
#' Make 2 plots, opne with the full time-series, another zooming into a portion of the simulation. Can create a PDF file.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param fileout the desired filename for the resulting PDF plot, if not given (NA) the plot goes to screen
#' @param w the width of the PDF plot. 
#' @param h the height of the PDF plot. 
#' @param colours the set of colours to be used for the existing strains. If \code{length(colours)<nStrains}, colours are reused (\code{nStrains} is the number of strains in \code{data}). If not defined by the user, the \code{rainbow} collection is used. 
#' @param xiObs the starting proportion of time used to zoom into the time-series. For example \code{xiObs=0.5} will start zooming from the middle of the time-series.
#' @param xfObs the end proportion of time used to zoom into the time-series. 
#' @param mainLeft main title for the left plot. 
#' @param mainRight main title for the right plot. 
#' @param ymax numeric value for the maximum to be represented in the Y axis.
#' @param yylab title for the y-axis. 
#' @param xxlab title for the x-axis. 
#' @param markStrains list of strain IDs (numbers), used to highlight the given strains in the plot. The highlight will consist of an increase in the thickness of the lines and, when \code{length(colours)} is 2, the first colour is used for these strains and the second colour for the remaining. 
#' @param addLegend boolean flag whether to add a legend to the time series plot.
plotY <- function(data, fileout=NA, w=7, h=3, colours=NULL, xiObs=0.9, xfObs=1, markStrains=NULL, ymax=NULL,
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="proportion infected", xxlab="time", addLegend=FALSE){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)   

  nStrains<- ncol(data[[2]])/3

  X<- data[[1]]
  Y<- extractY(data) #infectious

  if(!is.na(fileout)) pdf(fileout, width=w, height=h, bg="white")
  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotFullAndZoomInSeries(X, Y, nStrains, colours, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, markStrains, ymax, legendThis=addLegend)

  if(!is.na(fileout))  a=dev.off()

}


#' Plot the specific-immunity (Z) time-series of all strains in the system.
#' 
#' Makes two plots, one with the full time-series, another zooming into a portion of the simulation. Can create a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colours see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param ymax see \code{?plotY} for details.
#' @param mainLeft see \code{?plotY} for details.
#' @param mainRight see \code{?plotY} for details.
#' @param yylab see \code{?plotY} for details.
#' @param xxlab see \code{?plotY} for details.
#' @param markStrains see \code{?plotY} for details.
#' 
plotZ <- function(data, fileout=NA, w=7, h=3, colours=NULL, xiObs=0.9, xfObs=1, markStrains=NULL, ymax=NULL,
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="proportion with specific-immunity", xxlab="time"){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)

  nStrains<- ncol(data[[2]])/3

  X<- data[[1]]
  Z<- extractZ(data) #specific-immunity

  if(!is.na(fileout)) pdf(fileout, width=w, height=h, bg="white")
  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotFullAndZoomInSeries(X, Z, nStrains, colours, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, markStrains, ymax)

  if(!is.na(fileout))  a=dev.off()


}

#' Plot the cross-reactive (W) time-series of all strains in the system.
#' 
#' Makes 2 plots, one with the full time-series, another zooming into a portion of the simulation. Can export to a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colours see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param ymax see \code{?plotY} for details.
#' @param mainLeft see \code{?plotY} for details.
#' @param mainRight see \code{?plotY} for details.
#' @param yylab see \code{?plotY} for details.
#' @param xxlab see \code{?plotY} for details.
#' @param markStrains see \code{?plotY} for details.
#'  
plotW <- function(data, fileout=NA, w=7, h=3, colours=NULL, xiObs=0.9, xfObs=1, markStrains=NULL, ymax=NULL,
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="proportion cross-reactive", xxlab="time"){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)

  nStrains<- ncol(data[[2]])/3

  X<- data[[1]]
  W<- extractZ(data) #cross-reactive

  if(!is.na(fileout)) pdf(fileout, width=w, height=h, bg="white")
  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotFullAndZoomInSeries(X, W, nStrains, colours, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, markStrains, ymax)

  if(!is.na(fileout))  a=dev.off()


}


#' Plot the relative-prevalence of the infectious (Y) time-series for all strains in the system.
#' 
#' Makes 2 plots, one with the full time-series, another zooming into a portion of the simulation. Can create a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colours see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param ymax see \code{?plotY} for details.
#' @param mainLeft see \code{?plotY} for details.
#' @param mainRight see \code{?plotY} for details.
#' @param yylab see \code{?plotY} for details.
#' @param xxlab see \code{?plotY} for details.
#' @param markStrains see \code{?plotY} for details.
#' @param method a character string to choose the method to be used for the estimation of the pathogen's total prevalence. Methods are \code{"host"} and \code{"strain"} and relate to how total 
#' prevalence of the pathogen is estimated. When \code{method="host"} the function \code{extractPathogenPrevByStrain} is called and when \code{method="strain"} 
#' the function \code{extractPathogenPrevByHost} is called. See the help of each function for how they differ. Estimations are expected to be very similar using the two methods.
#'  
plotYRelPrevalence <- function(data, fileout=NA, w=7, h=3, colours=NULL, xiObs=0.9, xfObs=1, markStrains=NULL,  ymax=NULL,
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="proportion infected (relative prevalence)", xxlab="time", method="host"){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)

  nStrains<- ncol(data[[2]])/3

  X<- data[[1]]
  Yr<- extractYRelPrevalences(data, method) #infectious relative prevalences

  if(!is.na(fileout)) pdf(fileout, width=w, height=h, bg="white")
  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotFullAndZoomInSeries(X, Yr, nStrains, colours, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, markStrains, ymax)

  if(!is.na(fileout))  a=dev.off()

}

#' Plot total prevalence of the pathogen.
#' 
#' Makes 2 plots, one with the full time-series, another zooming into a portion of the simulation. Can export to a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colour see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param ymax see \code{?plotY} for details.
#' @param mainLeft see \code{?plotY} for details.
#' @param mainRight see \code{?plotY} for details.
#' @param yylab see \code{?plotY} for details.
#' @param xxlab see \code{?plotY} for details.
#' @param method a character string to choose the method to be used. Methods are \code{"host"} and \code{"strain"} and relate to how total 
#' prevalence of the pathogen is estimated. When \code{method="host"} the function \code{extractPathogenPrevByStrain} is called and when \code{method="strain"} 
#' the function \code{extractPathogenPrevByHost} is called. See the help of each function for how they differ. Estimations are expected to be very similar using the two methods.
#'
plotPathogenPrevalence <- function(data, fileout=NA, w=7, h=3, colour=NULL, xiObs=0.9, xfObs=1, ymax=NULL,
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="pathogen prevalence (proportion)", xxlab="time", method="host"){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)

  nStrains<- ncol(data[[2]])/3

  X<- data[[1]]

  if(method=="host"){
    P<- extractPathogenPrevByStrain(data) #total prevalence
  }else if(method=="strain"){
    P<- extractPathogenPrevByHost(data) #total prevalence
  }else{
    msg="The method given to calcSingleStrainDominance is invalid, check ?calcSingleStrainDominance for methods."
    stop(msg)
  }

  if(!is.na(fileout))
    pdf(fileout, width=w, height=h, bg="white")

  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

    .plotOneTSWithZoom(X, P, colour, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, ymax)


  if(!is.na(fileout))  
    a=dev.off()


}

#' Plot diversity measures for the infectious (Y) classes.
#' 
#' Makes two plots, one with the full time-series, another zooming into a portion of the simulation. Can create a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colour see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param ymax see \code{?plotY} for details.
#' @param mainLeft see \code{?plotY} for details.
#' @param mainRight see \code{?plotY} for details.
#' @param yylab see \code{?plotY} for details.
#' @param xxlab see \code{?plotY} for details.
#' @param method character string for the method to use for diversity. See \code{?calcDiversity}.
#' 
plotYDiversity <- function(data, fileout=NA, w=7, h=3, colour=NULL, xiObs=0.9, xfObs=1, ymax=NULL, 
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="diversity", xxlab="time", method="shannon"){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)
  
  X<- data[[1]]
  Y<- extractY(data) #infected

  #calc all diversity, then trim in plot
  div<- calcDiversity(Y, xiObs=0, xfObs=1, method=method)

  yylab= paste(yylab, " (class Y, ",method," index)", sep="")

  if(!is.na(fileout))
    pdf(fileout, width=w, height=h, bg="white")

  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotOneTSWithZoom(X, div,  colour, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, ymax)


  if(!is.na(fileout))  
    a=dev.off()


}

#' Plot diversity measures for the specific-immunity (Z) classes.
#' 
#' Makes 2 plots, one with the full time-series, another zooming into a portion of the simulation. Can create a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colour see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param ymax see \code{?plotY} for details.
#' @param mainLeft see \code{?plotY} for details.
#' @param mainRight see \code{?plotY} for details.
#' @param yylab see \code{?plotY} for details.
#' @param xxlab see \code{?plotY} for details.
#' @param method character string for the method to use for diversity. See \code{?calcDiversity}.
#' 
plotZDiversity <- function(data, fileout=NA, w=7, h=3, colour=NULL, xiObs=0.9, xfObs=1, ymax=NULL, 
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="diversity", xxlab="time", method="shannon"){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)
  
  X<- data[[1]]
  Z<- extractZ(data) #infected

  #calc all diversity, then trim in plot
  div<- calcDiversity(Z, xiObs=0, xfObs=1, method=method)

  yylab= paste(yylab, " (class Z, ",method," index)", sep="")

  if(!is.na(fileout))
    pdf(fileout, width=w, height=h, bg="white")

  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotOneTSWithZoom(X, div,  colour, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, ymax)


  if(!is.na(fileout))  
    a=dev.off()


}

#' Plot diversity measures for the cross-reactive (W) classes.
#' 
#' Makes 2 plots, one with the full time-series, another zooming into a portion of the simulation. Can create a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colour see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param ymax see \code{?plotY} for details.
#' @param mainLeft see \code{?plotY} for details.
#' @param mainRight see \code{?plotY} for details.
#' @param yylab see \code{?plotY} for details.
#' @param xxlab see \code{?plotY} for details.
#' @param method character string for the method to use for diversity. See \code{?calcDiversity}.
#' 
plotWDiversity <- function(data, fileout=NA, w=7, h=3, colour=NULL, xiObs=0.9, xfObs=1, ymax=NULL, 
                              mainLeft="full time-series", mainRight="zoomed-in time-series", yylab="diversity", xxlab="time", method="shannon"){

  .testPlotZYWParams(data, fileout, xfObs, xiObs)
  
  X<- data[[1]]
  W<- extractW(data) #infected

  #calc all diversity, then trim in plot
  div<- calcDiversity(W, xiObs=0, xfObs=1, method=method)
  
  yylab= paste(yylab, " (class W, ",method," index)", sep="")

  if(!is.na(fileout))
    pdf(fileout, width=w, height=h, bg="white")

  layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotOneTSWithZoom(X, div, colour, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, ymax)


  if(!is.na(fileout))  
    a=dev.off()


}

#' Calculate a measure of single-strain dominance (SSD) (\code{epsilon}).
#' 
#' This function estimates a measure of SSD for a simulated time-series of infectious individuals (Y). 
#' Single-strain dominance can be quantified by \code{epsilon}, the measure obtained by comparing the relative prevalence of the two
#' most common antigenic variants within single epidemics and then averaging across extended periods of time, or, more formally, averaging
#' across each of the epidemics within the studied time window. The number and time point of each epidemic \code{Pi} is determined by addressing
#' total pathogen prevalence and identifying local maxima. Here, two estimates of total pathogen prevalence can be used via the argument \code{method}, see bellow.
#' \code{epsilon} is expected to vary between 0 and 1, with high values indicative of strong SSD within epidemics, 
#' as often found, for instance, in the antigenic evolution and epidemiological behaviour of influenza A viruses. \code{epsilon} 
#' has been used in several research publications - see references (2) and (5) for formal definitions (found in the documentation or output of function \code{readingMANTIS}).
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param xiObs the starting proportion of time to use for diversity. For example \code{xiObs=0.5} will start from the middle of the time-series.
#' @param xfObs the end proportion of time to use for diversity. 
#' @param method a character string to choose the method to be used. Methods are \code{"host"} and \code{"strain"} and relate to how total 
#' prevalence of the pathogen is estimated. When \code{method="host"} the function \code{extractPathogenPrevByStrain} is called and when \code{method="strain"} 
#' the function \code{extractPathogenPrevByHost} is called. See the help of each function for how they differ. Estimations are expected to be very similar using the two methods.
#'
#' @return epsilon
#'
calcSingleStrainDominance <- function(data, xiObs=0.5, xfObs=1.0, method="host"){

  if(length(data)==0){
    stop("data seems to be empty. See '?extractPathogenPrevByStrain")
  }

  listmethods <- c("host", "strain")

  #trim the data to x range
  rr= (xiObs*nrow(data[[2]])):(xfObs*nrow(data[[2]]))
  data[[2]]= data[[2]][rr,] 

  Y= extractY(data)

  if(method=="host"){
    G= extractPathogenPrevByStrain(data)
  }else if(method=="strain"){
    G= extractPathogenPrevByHost(data)
  }else{
    msg="The method given to calcSingleStrainDominance is invalid, check ?calcSingleStrainDominance for methods."
    stop(msg)
  }

  nPeaks = 1;#number of peaks in prevalence (=1 to prevent division from zero below)
  epsilon = 0; #single strain dominance
  # tp is an indexing variable [short for timepoint]
  for(tp in 2:(length(G)-1)){
    if(G[tp] > max(G[tp-1],G[tp+1])){
      # i.e. if there is a local maximum in G at tp ...
      maxY = max(Y[tp,])
      secY = max(Y[tp,][-which.max(Y[tp,])])
      epsilon = epsilon + (maxY - secY)/maxY;#running total of epsilon (equivalent to nPeaks*epsilon)
      nPeaks = nPeaks + 1;
    }
  }
  epsilon = epsilon/nPeaks
  return(epsilon)
}

#' Returns a time-series for the total prevalence of the simulated pathogen.
#' 
#' The number of infectious individuals to each strain (Y) is used to calculate the total pathogen prevalence,
# 'i.e. as the sum of the prevalence of each individual strain. This gives the effective total population size
#' of the pathogen: in effect, each infected individual is counted as many times as they are infected. It is
#' therefore possible for this value to exceed 1 in cases when the prevalence of any individual strain is very high. 
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#'
#' @return a numeric array with the time-series of the total prevalence for the simulated pathogen.
#'
extractPathogenPrevByStrain <- function(data) {

  if(length(data)==0){
    stop("data seems to be empty. See '?extractPathogenPrevByStrain")
  }

  Y<- extractY(data) #infectious
  P<- rowSums(Y)  
  return( as.numeric(P) )
}

#' Returns a time-series for the total prevalence of the simulated pathogen.
#' 
#' The number of infectious individuals to each strain (Y) is used to estimate the total pathogen prevalence, i.e. as the fraction of the
#' population that is infected with at least one strain. In effect, each infectious class is considered independently and each infected individual 
#' is counted once, regardless of how many times they may be infected. This value is therefore bounded between 0 and 1.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#'
#' @return a numeric array with the time-series of the total prevalence for the simulated pathogen.
#'
extractPathogenPrevByHost <- function(data) {

  if(length(data)==0){
    stop("data seems to be empty. See '?extractPathogenPrevByHost")
  }

  Y<- extractY(data) #infectious
  mP = (1-apply(1-Y,1,prod))

  return( as.numeric(mP) )
}


#' Returns the set of strains sharing alleles with strain \code{i}.
#' 
#' The \code{'shared epitopes'} matrix is used to return a list of strain numbers that share at least one allele with strain \code{i} given as argument \code{strain}.
#' The matrix is the third element of the list returned by \code{runMANTIS} after running a simulation. For details on the \code{'shared epitopes'} matrix see \code{?runMANTIS}.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param strain a strain number. Used to query the \code{'shared epitopes'} matrix to find the set of strains that shared alleles with \code{strain}. If \code{strain} is NULL, the entire \code{'shared epitopes'} matrix is returned.
#'
#' @return a numeric array with strain numbers.
#'
withSharedEpitopes <- function(data, strain=NULL){
  if(!is.null(strain)){
    if(!is.numeric(strain)){
      msg="Strain IDs must be numeric. See ?withSharedEpitopes"
      stop(msg)
    }
    return(unique(as.vector(data[[3]][strain,])))    
  }else{
    return(data[[3]])
  }
}

#' Returns the time-series for the infectious (Y) classes.
#' 
#' The list returned from \code{runMANTIS} is used to obtain only the time-series of the Y classes. See \code{?runMANTIS} for what it returns.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#'
#' @return a matrix in which each column is an infectious class \code{Yi} for strain \code{i}.
#'
extractY <- function(data) {

  if(length(data)==0){
    stop("data seems to be empty. See '?extractY")
  }

  nStrains<- ncol(data[[2]])/3
  Y<- data[[2]][,(2*nStrains+1):(3*nStrains)] #infectious  
  return( as.matrix(Y) )
}


#' Returns the time-series for the cross-reactive (W) classes.
#' 
#' The list returned from \code{runMANTIS} is used to obtain only the time-series of the W classes. See \code{?runMANTIS} for what it returns.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#'
#' @return a matrix in which each column is an cross-reactive class \code{Wi} for strain \code{i}.
#'
extractW <- function(data) {

  if(length(data)==0){
    stop("data seems to be empty. See '?extractW")
  }

  nStrains<- ncol(data[[2]])/3
  W<- data[[2]][,(nStrains+1):(nStrains*2)] #cross-reactive
  return( as.matrix(W) )
}

#' Returns the time-series for the specific-immunity (Z) classes.
#' 
#' The list returned from \code{runMANTIS} is used to obtain only the time-series of the Z classes. See \code{?runMANTIS} for what it returns.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#'
#' @return a matrix in which each column is an specific-immunity class \code{Zi} for strain \code{i}.
#'
extractZ <- function(data) {

  if(length(data)==0){
    stop("data seems to be empty. See '?extractZ")
  }

  nStrains<- ncol(data[[2]])/3
  Z<- data[[2]][,1:nStrains] #specific-immunity
  return( as.matrix(Z) )
}

#' Returns the relative prevalence time-series for the infectious (Y) classes.
#' 
#' The list returned from \code{runMANTIS} is used to obtain only the relative prevalence time-series of the Y classes. See \code{?runMANTIS} for what it returns.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param method a character string to choose the method to be used for the estimation of the pathogen's total prevalence. Methods are \code{"host"} and \code{"strain"} and relate to how total 
#' prevalence of the pathogen is estimated. When \code{method="host"} the function \code{extractPathogenPrevByStrain} is called and when \code{method="strain"} 
#' the function \code{extractPathogenPrevByHost} is called. See the help of each function for how they differ. Estimations are expected to be very similar using the two methods.
#' 
#' @return a matrix in which each column is an infectious class \code{Yi} for strain \code{i}. The series are calculated by dividing each strain's prevalence by the total pathogen prevalence (as obtained by \code{extractPathogenPrevByStrain}).
#'
extractYRelPrevalences <- function(data, method="host") {

  if(length(data)==0){
    stop("data seems to be empty. See '?extractYRelPrevalences")
  }

  Y<- extractY(data)

  listmethods <- c("host", "strain")

  if(method=="host"){
    tot= extractPathogenPrevByHost(data)
  }else if(method=="strain"){
    tot= extractPathogenPrevByStrain(data)
  }else{
    msg="The method given is invalid, check ?extractYRelPrevalences for methods."
    stop(msg)
  }

  Yr<- Y/(tot+0.00000001) #avoid division by zero
  
  return( as.matrix(Yr) )
}


#' Calculates diversity measures on strain's time-series.
#' 
#' A matrix with time-series is used to generate estimates of diversity in time. These estimates can be generated by two
#' standard methods: \code{Shannon} and \code{Simpson} indexes. The Shannon Index is defined as \code{SH = -sum Yr_i log Yr_i}, 
#' where \code{Yr_i} is the proportional abundance of strain \code{i}; log is the exponential logarithm. The Simpson Index is 
#' based on \code{SI = sum Yr_i^2}, returning \code{1-SI}.
#' 
#' @param tsSeries a matrix in which columns are the time-series to apply the diversity method. Such a matrix can be obtained from running a 
#' simulation with \code{runMANTIS}. For example, if \code{simdata=runMANTIS(...)}, then \code{Y=extractY(simdata)} can be used to obtain a matrix of infectious classes. 
#' See \code{?runMANTIS}, \code{?extractY}, \code{?extractW} and \code{?extractZ} for details.
#'
#' @param method a character string of two possible values, \code{"shannon"} or \code{"simpson"}, see description for details.
#' @param xiObs the starting proportion of time to use for diversity. For example \code{xiObs=0.5} will start from the middle of the time-series.
#' @param xfObs the end proportion of time to use for diversity. 
#' 
#' @return a numeric array for the diversity in time.
#'
calcDiversity <- function(tsSeries, xiObs=0.5, xfObs=1.0, method= "shannon") {

    if(is.list(tsSeries)==TRUE){
      msg="You have given tsSeries as a list but it must be a matrix or data.frame. You may have given the output of runMANTIS instead of a particular time-series of an epidemiological class. See ?calcDiversity for details."
      stop(msg)
    }

    #trim data to x range
    rr= (xiObs*nrow(tsSeries)):(xfObs*nrow(tsSeries))
    tsSeries= tsSeries[rr,]

    tsSeries <- drop(as.matrix(tsSeries))

    #listmethods <- c("shannon", "simpson")
    #method <- match.arg(method, listmethods)
    
    #calc relative measures
    tsSeries <- tsSeries/rowSums(tsSeries)

    if (method == "shannon"){
        tsSeries <- -tsSeries * log(tsSeries, exp(1))
        divI <- apply(tsSeries, 1, sum, na.rm = TRUE)
    }else if (method == "simpson"){
        tsSeries <- tsSeries * tsSeries
        divI <- apply(tsSeries, 1, sum, na.rm = TRUE)
        divI <- 1.0 - divI        
    }else {
      msg= paste("The given method '",method,"' is invalid. See ?calcDiversity for possible methods.", sep="")
      stop(msg)
    }

    return(divI)
}


#' Measures single-strain dominance (SSD) for a set of different simulations.
#' 
#' Various simulations can be run sequencially, for the same epidemiological parameters, while varying
#' the cross-immunity parameter \code{gamma}; for each run, SSD is calculated.
#' 
#' @param gammas a numeric array with values for the \code{gamma} parameter.
#' @param method character string for the method to be used in the SSD measure. See \code{?calcSingleStrainDominance} for details.
#' @param epiStruc see \code{?runMANTIS} for details.
#' @param tMax see \code{?runMANTIS} for details.
#' @param tObsPer see \code{?runMANTIS} for details.
#' @param tInt see \code{?runMANTIS} for details.
#' @param tStep see \code{?runMANTIS} for details.
#' @param initCondY see \code{?runMANTIS} for details.
#' @param beta see \code{?runMANTIS} for details.
#' @param sigma see \code{?runMANTIS} for details.
#' @param mu see \code{?runMANTIS} for details.
#' @param xiObs the starting proportion of time to use for SSD. For example \code{xiObs=0.5} will start from the middle of the time-series.
#' @param xfObs the end proportion of time to use for SSD. 
#'
#' @return a numeric array with the measures for single-strain dominance in each simulation with different \code{gamma}.
#'
measureSSDfromGammaRange <- function(gammas, method, epiStruc, tMax, tObsPer, tInt, tStep, initCondY, beta, sigma, mu, xiObs=0.6, xfObs=1.0){
  SSDs=c()
  for(gamma in gammas){
      cat("Running MANTIS for gamma:", round(gamma,3), "\n")
      simdata<- runMANTIS(epiStruc, tMax, tObsPer, tInt, initCondY, beta, gamma, sigma, mu)
      ssd<- calcSingleStrainDominance(simdata, xiObs=xiObs, xfObs=xfObs, method=method)
      SSDs= c(SSDs, ssd)
  }
  return(SSDs)
}



#' Measures mean strain diversity for a set of different simulations with varying gamma.
#' 
#' Various simulations can be run sequencially, for the same epidemiological parameters, while varying the
#' cross-immunity parameter \code{gamma}; for each run, mean strain diversity is calculated.
#' 
#' @param gammas a numeric array with values for the \code{gamma} parameter.
#' @param method character string for the method to be used in the diversity measure. See \code{?calcDiversity} for details.
#' @param epiStruc see \code{?runMANTIS} for details.
#' @param tMax see \code{?runMANTIS} for details.
#' @param tObsPer see \code{?runMANTIS} for details.
#' @param tInt see \code{?runMANTIS} for details.
#' @param tStep see \code{?runMANTIS} for details.
#' @param initCondY see \code{?runMANTIS} for details.
#' @param beta see \code{?runMANTIS} for details.
#' @param sigma see \code{?runMANTIS} for details.
#' @param mu see \code{?runMANTIS} for details.
#' @param xiObs the starting proportion of time to use for SSD. For example \code{xiObs=0.5} will start from the middle of the time-series.
#' @param xfObs the end proportion of time to use for SSD. 
#'
#' @return a numeric array with the measures for mean strain diversity in each simulation with different \code{gamma}.
#'
measureDiversityfromGammaRange <- function(gammas, method, epiStruc, tMax, tObsPer, tInt, tStep, initCondY, beta, sigma, mu, xiObs=0.6, xfObs=1.0){
  DIVs=c()
  for(gamma in gammas){
      cat("Running MANTIS for gamma:", round(gamma,3), "\n")
      simdata<- runMANTIS(epiStruc, tMax, tObsPer, tInt, initCondY, beta, gamma, sigma, mu)
      div<- calcDiversity(extractY(simdata), xiObs=xiObs, xfObs=xfObs, method=method)
      DIVs= c(DIVs, mean(div))
  }
  return(DIVs)
}


###################################################################
####### hidden, internal functions for MANTIS

.testPlotZYWParams <- function(data, fileout, xfObs, xiObs){

  if(length(data)==0){
    stop("data seems to be empty. See '?plotY")
  }


  if(xfObs<= xiObs){
    stop("xfObs must be bigger than xiObs. See '?plotY")
  }  

  if(xfObs<0 | xiObs<0 | xfObs>1 | xiObs>1){
    stop("xfObs and xiObs must be in [0,1]. See '?plotY")
  }   

}

.plotFullAndZoomInSeries <- function(X, Y, nStrains, colours, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, markStrains, ymax, legendThis=FALSE){

  #default
  plotcols<- rainbow(nStrains, start=0.15)
  plotlwds<- rep(1, nStrains) 

  if(is.null(markStrains)){
    #then, manual colours or generate one per strain
    if(!is.null(colours)){
      plotcols<- rep(colours,1+nStrains/length(colours))
    }

  }else{
    #then, user is choosing to highlight subset of strains
    if(length(colours)!=2){
      msg="When choosing to mark a subset of strains, the number of colours given must be 2. One for the 'marked' set and another for the remaining strains. See ?plotY for details."
      stop(msg)
    }
    #user is giving 2 colours for subsets
    plotcols<- rep(colours[2], nStrains)
    plotcols[markStrains]<- colours[1]
    
    plotlwds<- rep(1, nStrains)
    plotlwds[markStrains]<- 2
  }

    rr= ((xiObs)*length(X)):((xfObs)*length(X)) #wanted zoom in range

    if(is.null(ymax)){
      ymax1=max(Y, na.rm=TRUE)
      ymax2=max(Y[rr,], na.rm=TRUE)
    }else{
      ymax1=ymax
      ymax2=ymax
    }

    ivert= X[min(rr)]
    fvert= X[max(rr)]

    # display Y dynamics in a plot
    ymin = min(Y, na.rm=TRUE)
    plot(X,Y[,1],type="l",col=plotcols[1],ylim=c(ymin,ymax1),ylab=yylab,xlab=xxlab,main=mainLeft, lwd=plotlwds[1])
    for(i in 2:nStrains){ lines(X,Y[,i],type="l",col=plotcols[i], lwd=plotlwds[i]) }
    abline(v=ivert, col="grey", lt=2, lwd=2)
    abline(v=fvert, col="grey", lt=2, lwd=2)
    if(legendThis){
      legend("topright",legend=1:nStrains,col=plotcols,lwd=2,cex=0.9)
    }
    box(lwd=2)

    # display late Y dynamics in a plot
    ymin = min(Y[rr,], na.rm=TRUE)    
    X= X[rr]
    plot(X, Y[rr,1],type="l",col=plotcols[1],ylim=c(ymin,ymax2),ylab=yylab,xlab=xxlab,main=mainRight, lwd=plotlwds[1])
    for(i in 2:nStrains){ lines(X,Y[rr,i],type="l",col=plotcols[i], lwd=plotlwds[i]) }
    box(lwd=2)




}

.plotOneTSWithZoom <- function(X, Y, colour, xiObs, xfObs, mainLeft, mainRight, yylab, xxlab, ymax){

  if(is.null(colour)){
    plotcols="red3"
  }else{
    plotcols=colour
  }

    rr= ((xiObs)*length(X)):((xfObs)*length(X)) #wanted zoom in range

    if(is.null(ymax)){
      ymax1=max(Y, na.rm=TRUE)
      ymax2=max(Y[rr], na.rm=TRUE)
    }else{
      ymax1=ymax
      ymax2=ymax
    }

    ivert= X[min(rr)]
    fvert= X[max(rr)]

    # display Y dynamics in a plot
    ymin = min(Y, na.rm=TRUE)
    plot(X,Y,type="l",col=plotcols,ylim=c(ymin,ymax1),ylab=yylab,xlab=xxlab,main=mainLeft)#
    abline(v=ivert, col="grey", lt=2, lwd=2)
    abline(v=fvert, col="grey", lt=2, lwd=2)    
    box(lwd=2)

    # display late Y dynamics in a plot
    ymin = min(Y[rr], na.rm=TRUE)    
    X= X[rr]
    Y= Y[rr]
    plot(X, Y,type="l",col=plotcols,ylim=c(ymin,ymax2),ylab=yylab,xlab=xxlab,main=mainRight)
    box(lwd=2)


}

.writeCSVTS <- function(M, fileout, row.names=FALSE){

  write.table(M, file=fileout, row.names=row.names, col.names=TRUE, sep=",")

}
 
#### (ENDCODE_V1.0)
#####################################################################################
#####################################################################################
  
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#### FUNCTIONS ADDED ON MANTIS V2.0. (STARTCODE_V2.0)
#### THERE MAY HAVE BEEN CHANGES, UPDATES OR BUG CORRECTIONS IN OTHER PARTS OF THE CODE. 

#' Extract antigenic novelty dynamics.
#' 
#' Extracts time series containing the solution for antigenic dynamics based on novelty. Novelty is defined
#' as the first appearance of variants (strains) in the population. This crucially depends on the assumption
#' of the theoretical host population size. See the definition of \code{extThreshold} below for details.
#'  
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param extThreshold theoretical extinction threshold for the pathogen. Since MANTIS is based on deterministic and
#' continuous numerical simulations, strains are always present in the population (their prevalences are always
#' bigger than zero). This is particularly important for the concept of antigenic novelty - by necessarily having
#' to initialize all strains at prevalences bigger than zero, novelty is readily 100 percent at the initial time
#' step. For this reason, the consideration of an extinction threshold was added. This allows the user to consider
#' theoretical (host) population sizes, assuming that prevalences under the threshold should equate to the virtual
#' extinction of pathogen strains. Variants therefore emerge (appear for the first time) as novel types only when
#' they breach the threshold.
#'
#' @return a list with two data.frames. The first data.frame contains the time series in which the first column is
#' time and second column is the number of the variant (strain) that has emerged for the first time above the
#' theoretical extinction threshold (\code{extThreshold}). The second data.frame contains the time series in which
#' the first column is time and the second column is the percent of the antigenic space that has been explored by
#' novelty.
#'
extractNoveltyVariant<- function(data, extThreshold){
	X<- data[[1]]
	Y<- extractY(data) #infectious
	nStrains<- ncol(data[[2]])/3
	#get variants that are persistent in time
	extantOnes<- function(vals){
		return (which(vals>extThreshold))
	}
	extantInTime= apply(Y, MARGIN=1, FUN=extantOnes)
	#from the extant ones, check
	newPersSpaceTravelled= c()
	spaceTravelled= c() #% of space already explored
	alreadyPresent= c() #per time step, which have already been present/emerged
	if(length(!is.na(extantInTime))==0){
		stop(paste("Oops! The threshold for extinction 'extThreshold'=",extThreshold,"is too small for this
			simulation as it is impossible to find strain prevalences above it in the entire time series. Please
			decrease extThreshold and try again."))
	}
	for(ipers in 1:length(extantInTime)){
		pers= as.numeric(extantInTime[[ipers]])
		newEmerged= pers[!(pers %in% alreadyPresent)] #before updating alreadyPresent
		alreadyPresent= unique(c(alreadyPresent, pers))
		for(ne in newEmerged)
			newPersSpaceTravelled= rbind(newPersSpaceTravelled, c(X[ipers], ne))
		spaceTravelled= c(spaceTravelled, round(sum( 100*(1:nStrains) %in% alreadyPresent )/nStrains,3))
	}
	colnames(newPersSpaceTravelled)= c("time","newVariant")
	return(list(novelvariant=data.frame(newPersSpaceTravelled), spacetravelled=data.frame(time=X,space=spaceTravelled)))
}

#' Extract antigenic dominance dynamics.
#' 
#' Extracts time series containing the solution for antigenic dynamics based on dominance. Dominance is based on
#' prevalence levels, with the variant (strain) presenting the highest prevalence considered to be dominant.
#' This indirectly depends on the assumption of the theoretical host population size. See the definition of
#' \code{extThreshold} below for details.
#'  
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param extThreshold theoretical extinction threshold for the pathogen. Since MANTIS is based on deterministic and
#' continuous numerical simulations, strains are always present in the population (their prevalences are always
#' bigger than zero). This is particularly important for the concept of antigenic novelty (see \code{?extractNoveltyVariant})
#' and therefore becomes necessary for the concept of antigenic dominance - dominance should only be analysed in the
#' context of novelty, since dominant variants must have emerged (appeared for the first time) before they dominate.
#'
#' @return a data.frame in which the first column is time, the second column is the variant (strain) number that is
#' dominating and the third column is the percent of antigenic space explored by dominance. Values \code{NA} are
#' used for time steps in which all variants are below the extinction threshold and therefore dominance is not
#' biologically relevant.
#'
extractDomVariant<- function(data, extThreshold){
	X<- data[[1]]
	Y<- extractY(data) #infectious
	nStrains<- ncol(data[[2]])/3
	#get the dominant variant per time step
	chooseMax<- function(vals){
		return(which(vals==max(vals) & vals>extThreshold)[1])
	}
	dominantV=apply(Y[,1:ncol(Y)], MARGIN=1,FUN=chooseMax)
	#assess how much of the antigenic space has been reached in time
	domSpaceTravelled=c()
	for(findex in 1:length(dominantV)){
		vals= dominantV[1:findex]
		domSpaceTravelled= c(domSpaceTravelled, round(sum( 100*(1:nStrains) %in% vals )/nStrains,3))
	}		
	res= data.frame(time=X, domvariant=dominantV,spacetravelled=domSpaceTravelled)
	return(res)
}

#' Plot antigenic dynamics.
#' 
#' Makes 4 plots. Top-left subplot presents the simulated time series of the Y classes with the \code{extThreshold} highlighted with a dashed black line. Top-right subplot presents antigenic dominance dynamics (See \code{?extractDomVariant} for details). Bottom-left subplot presents antigenic novelty dynamics (See \code{?extractNoveltyVariant} for details). Bottom-right subplot presents the percentage of antigenic space explored by novelty and dominance in time. Can create a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param extThreshold see \code{?extractDomVariant} or \code{?extractNoveltyVariant} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colours see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param mainTopLeft title for top-left subplot.
#' @param mainTopRight title for top-right subplot.
#' @param mainBottomLeft title for bottom-left subplot.
#' @param mainBottomRight title for bottom-right subplot.
#' @param yylabTopLeft tile for top-left subplot y-axis.
#' @param yylabTopRight tile for top-right subplot y-axis.
#' @param yylabBottomLeft tile for bottom-left subplot y-axis..
#' @param yylabBottomRight tile for bottom-right subplot y-axis.
#' @param xxlab see \code{?plotY} for details.
#'
plotAntigenicSpaceDyn <- function(data, extThreshold, fileout=NA, w=7*1.5, h=3*2.5, colours=NULL, xiObs=0, xfObs=1, 
			mainTopLeft="zoomed-in time-series", mainTopRight="antigenic dominance", mainBottomLeft="antigenic novelty", mainBottomRight="antigenic space explored in time", yylabTopLeft="proportion infected", yylabTopRight="variant", yylabBottomLeft="variant", yylabBottomRight="percentage", 
            xxlab="time"){

	.testPlotZYWParams(data, fileout, xfObs, xiObs)
	.testExtantThreshold(extThreshold,"plotAntigenicSpaceDyn")
	
	nStrains<- ncol(data[[2]])/3
	X<- data[[1]]
	Y<- extractY(data) #infectious
	
	#extract dominant variants in time
	dominance= extractDomVariant(data, extThreshold)

	#extract novelty variants in time
	novelty= extractNoveltyVariant(data, extThreshold)

	.plotAntSpaceDyn(X, Y, extThreshold, dominance, novelty, nStrains, fileout, w, h, colours, xiObs, xfObs, mainTopLeft, mainTopRight, mainBottomLeft, mainBottomRight, yylabTopLeft, yylabTopRight, yylabBottomLeft, yylabBottomRight, xxlab)
}

#' Export antigenic dominance dynamics.
#' 
#' Creates a comma separated CSV text file in which the columns are the solution of the simulation in terms of antigenic
#' novelty in time. The file (\code{fileout}) contains the output of which variant (strain) is dominating
#' and the percentage of the antinegic space that has been explored by dominance, in time - first column is time,
#' second column is the variant (strain) number that is dominating and third column the percentage of space
#' already explored, in time.
#'  
#' See \code{?extractDomVariant} for details on the concept of antigenic dominance.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param extThreshold the theoretical extinction threshold for the pathogen. See \code{?extractNoveltyVariant} for details.   
#' @param fileout the name of the output CSV file. It defaults to "dominance.csv".
#'
exportDominance <- function(data, extThreshold, fileout="dominance.csv"){

	if(length(data)==0){
	stop("data seems to be empty. see '?exportdominance")
	}
	if(!is.character(fileout)){
	stop("fileout has to be a set of characters. see ?exportdominance")
	}
	.testExtantThreshold(extThreshold,"exportDominance")
	#extract dominant variants in time
	dominance= extractDomVariant(data, extThreshold)
	.writeCSVTS(dominance, fileout)
}


#' Export antigenic novelty dynamics.
#' 
#' Creates 2 comma separated CSV text files in which the columns are the solution of the simulation in terms of antigenic
#' novelty in time. The first file (\code{fileout1}) contains the output of which novel variants (strains) have emerged
#' above the \code{extThreshold} for the first time - first column is time and the second the variant (strain) number.
#' The second file (\code{fileout2}) containts the output of how much of the possible antigenic space has been
#' explored, through novelty, in time - first column is time, second column is percentage of all antigenic space explored.
#'  
#' See \code{?extractNoveltyVariant} for details on the concept of antigenic novelty.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param extThreshold the theoretical extinction threshold for the pathogen. See \code{?extractNoveltyVariant} for details.   
#' @param fileout1 the name of the first output CSV file. It defaults to "novelty.new.variants.csv".
#' @param fileout2 the name of the second output CSV file. It defaults to "novelty.space.travelled.csv".
#'
exportNovelty <- function(data, extThreshold, fileout1="novelty.new.variants.csv", fileout2="novelty.space.travelled.csv"){

	if(length(data)==0){
		stop("data seems to be empty. see '?exportdominance")
	}
	if(!is.character(fileout1)){
		stop("fileout has to be a set of characters. see ?exportdominance")
	}
	if(!is.character(fileout2)){
		stop("fileout has to be a set of characters. see ?exportdominance")
	}	
	.testExtantThreshold(extThreshold,"exportDominance")
	#extract novelty variants in time
	novelty= extractNoveltyVariant(data, extThreshold)
	.writeCSVTS(novelty$novelvariant, fileout1)
	.writeCSVTS(novelty$spacetravelled, fileout2)
}

###################################################################
####### hidden, internal functions for MANTIS


.testExtantThreshold<- function(extThreshold, funCall){
	minT=1e-50
	if(extThreshold<minT){
		stop(paste("Oops! For numerical reasons, the minimum value for extThreshold is ",minT,", please increase 
		extThreshold and try again. See ?",funCall,"for details.",sep=""))
	}
	if(is.null(extThreshold)){
		stop(paste("It is required to give an extinction threshold 'extThreshold'. See ?",funCall,"for details.",sep=""))
	}
}


.plotAntSpaceDyn <- function(X, Y, extThreshold, dominance, novelty, nStrains, fileout, w, h, colours, xiObs, xfObs, mainTopLeft, mainTopRight, mainBottomLeft, mainBottomRight, yylabTopLeft, yylabTopRight, yylabBottomLeft, yylabBottomRight, xxlab){

	#default
	plotcols<- rainbow(nStrains, start=0.15)
	plotlwds<- rep(1, nStrains) 

	#manual colours or generate one per strain?
	if(!is.null(colours)){
		plotcols<- rep(colours,1+nStrains/length(colours))
	}

	if(!is.na(fileout))
		pdf(fileout, width=w, height=h, bg="white")
	
	rr= ((xiObs)*length(X)):((xfObs)*length(X)) #wanted zoom in range
	X= X[rr]
	minX= min(X)
	maxX= max(X)
	ymaxTL=max(Y[rr,], na.rm=TRUE)
	yminTL=min(Y[rr,], na.rm=TRUE) 
	ymaxTR=nStrains
	ymaxBL=nStrains
	ymaxBR=100

	dominantV= dominance$domvariant
	domSpaceTravelled= dominance$spacetravelled

	noveltyInTime= novelty$novelvariant
	noveltySpace= novelty$spacetravelled

	layout(matrix(seq(1,4), ncol= 2, byrow=TRUE))
	par(mar=c(4, 4, 2, 1), cex=0.7)

	# display late Y dynamics in a plot
	plot(X, Y[rr,1],type="l",col=plotcols[1],ylim=c(yminTL,ymaxTL),ylab=yylabTopLeft,xlab=xxlab,main=mainTopLeft, lwd=plotlwds[1])
	for(i in 2:nStrains){ lines(X,Y[rr,i],type="l",col=plotcols[i], lwd=plotlwds[i]) }
	abline(h=extThreshold,lwd=1.5,lty=2)
	box(lwd=2)

	# display late dominant variant in a plot
	indWithData=which(!is.na(dominantV[rr]))
	plot(X[indWithData], dominantV[rr][indWithData],type="s",col="orange",ylim=c(1,ymaxTR),ylab=yylabTopRight,xlab=xxlab,main=mainTopRight, lwd=0.8)
	lines(X[indWithData], dominantV[rr][indWithData],type="p",col="grey44", pch=20)
	box(lwd=2)

	rrNovelty= which(noveltyInTime$time>= minX & noveltyInTime$time<= maxX)
	# display how much of antigenic space has been reached
	plot(noveltyInTime$time[rrNovelty], noveltyInTime$newVariant[rrNovelty],type="s",col="green",ylim=c(1,ymaxBL),ylab=yylabBottomLeft,xlab=xxlab,main=mainBottomLeft, lwd=0.8)
	lines(noveltyInTime$time[rrNovelty], noveltyInTime$newVariant[rrNovelty],type="p",col="grey44", pch=20)
	box(lwd=2)	

	# display how much of antigenic space has been reached
	plot(dominance$time[rr], domSpaceTravelled[rr],type="s",col="orange",ylim=c(1,ymaxBR),ylab=yylabBottomRight,xlab=xxlab,main=mainBottomRight, lwd=2)
	lines(novelty$spacetravelled$time[rr], novelty$spacetravelled$space[rr],type="s",col="green", lwd=0.8, lty=2)
	legend("bottomrigh", legend=c("by dominance","by novelty"), col=c("orange","green"), lwd=1.2, cex=1.1, box.lwd=NA)
	box(lwd=2)

	if(!is.na(fileout))  
		a=dev.off()

}


#### (ENDCODE_V2.0)
#####################################################################################
#####################################################################################
  
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#### FUNCTIONS ADDED ON MANTIS V3.0. (STARTCODE_V3.0)
#### THERE MAY HAVE BEEN CHANGES, UPDATES OR BUG CORRECTIONS IN OTHER PARTS OF THE CODE.  


#' Run the Multilocus ANTIgenic Simulator (MANTIS) under changes in the beta parameter.
#' 
#' Function that runs the multilocus model assuming that a change in the beta of one or more strains will happen at a given point in time.
#' Here, only the parameters not included in a normal call to \code{runMANTIS} are described. For full details on a normal run of MANTIS see \code{?runMANTIS} for details.
#' 
#' @param tBetaChange a numeric value for the time step at which betas should be changed in value, as given by \code{changedBetas}.
#' @param changedBeta is the numeric value of beta to be attributed to \code{changedStrain}. See \code{?runMANTIS} for details on the beta parameter. 
#' @param changedStrain is the numeric id (numeber) of the strain to change the neta as in \code{changedBeta}. See \code{?runMANTIS} for details on the beta parameter. 
#' @return a numeric array with the population state, with the class order \code{Zi,Wi,Yi}.
runInvasionWithOneBetaChange<- function(epiStruc, tMax, tObsPer, tInt, initCondY, beta, gamma, sigma, mu, tBetaChange, changedBeta, changedStrain){
  
  if(tBetaChange>= tMax){
    stop("tBetaChange must be smaller than tMax. See ?runMANTISwithBetaChange for details.")
  }

  if(changedBeta<0){
    stop("changedBetas has to be a 'collection' of positive numbers with length equal to the number of strains. See '?runMANTISwithBetaChange")
  }  

  changedBetas<- beta
  changedBetas[changedStrain]<- changedBeta #this strain will have changed beta

  tFirstSim<- tBetaChange
  tSecondSim<- tMax-tBetaChange
  #run first sim to set (equillibrium) conditions before changing betas at tBetaChange
  cat("Running before betas change...\n")
  simdata1<- runMANTIS(epiStruc, tMax=tFirstSim, tObsPer, tInt, initCondY, beta, gamma, sigma, mu)
  #check this sim in a plot?
  #plotY(simdata1, xiObs=0, xfObs=0.99)
  #get the final state of the previous simulation, to start the next simulation
  initCondEqs<- extractFinalConditions(simdata1)
  initCondZ<- initCondEqs$initCondZ
  initCondW<- initCondEqs$initCondW
  initCondY<- initCondEqs$initCondY
  #run second sim when betas have changed, using initial conditions of first sim
  cat("Running after betas change...\n")
  simdata2<- runMANTIS(epiStruc, tMax=tSecondSim, tObsPer, tInt, initCondY, beta=changedBetas, gamma, sigma, mu, initCondZ=initCondZ, initCondW=initCondW)
  #check this sim in a plot?
  #plotY(simdata2, xiObs=0, xfObs=0.99)
  #aggregating the 2 runs into one
  simdata3<- aggregateSimulations(simdata1, simdata2)
  return(simdata3)
}

#' Get the population state (condition) at the last time step of a simulation.
#' 
#' Returns the population state.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @return a numeric array with the population state, with the class order \code{Zi,Wi,Yi}.
extractFinalConditions<- function(data){
  nStrains<- ncol(data[[2]])/3
  initCondEqs<- (data[[2]])[nrow(data[[2]]),]
  initCondZ<- initCondEqs[1:nStrains]
  initCondW<- initCondEqs[(nStrains+1):(nStrains+nStrains)]
  initCondY<- initCondEqs[(nStrains+nStrains+1):(nStrains+nStrains+nStrains)]   
  return(list(initCondZ=initCondZ,initCondW=initCondW,initCondY=initCondY))
}

#' Aggregate two MANTIS simulations into one.
#' 
#' Returns a new simulation.
#' 
#' @param data1 a list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param data2 a list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @return a list as obtained from running the simulation but now composed of data1 followed by data2.
aggregateSimulations<- function(data1, data2){

  tstep= data1[[1]][2]- data1[[1]][1]
  aggdata= data1

  #aggregate the simulation times
  aggdata[[1]]= c(aggdata[[1]], data2[[1]]+max(data1[[1]])+tstep)

  #aggregate the population dynamics
  aggdata[[2]]= rbind(aggdata[[2]], data2[[2]])

  return(aggdata)

}


#' Extract the allelic matrix.
#' 
#' Returns the allelic matrix of a simulation. See \code{?runMANTIS} for the definition of allelic matrix.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @return a matrix which represents the allelic matrix.
extractAllelicMatrix<- function(data){
	
	if(length(data)==0){
		stop("data seems to be empty. See '?extractAllelicMatrix")
	}

	return(data[[4]])
}

#' Extract the sequences of dominant strains in time.
#' 
#' Returns a matrix with the sequences of the dominant strains in time. This matrix is essentially
#' the allelic matrix joint with a column for time and a column for the number of the strain
#' that is dominating at each time step. See \code{?runMANTIS} for the definition of allelic matrix.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param extThreshold the theoretical extinction threshold for the pathogen. See \code{?extractNoveltyVariant} for details.
#' @return a matrix which represents the sequences of the dominant strains in time.
extractSeqOfDomVariant<- function(data, extThreshold=1e-4){

	if(length(data)==0){
		stop("data seems to be empty. See '?extractSeqOfDomVariant")
	}	

	.testExtantThreshold(extThreshold, "extractSeqOfDomVariant")

	allelicMatrix= extractAllelicMatrix(data)
	dominance= extractDomVariant(data, extThreshold=extThreshold)
	seqsOfDomVariant= allelicMatrix[dominance$domvariant,]
	seqsOfDomVariant= data.frame(time=dominance$time, domvariant=dominance$domvariant, seqsOfDomVariant)
	rownames(seqsOfDomVariant)<- NULL
	return(seqsOfDomVariant)
}
  
#' Export the allelic matrix.
#' 
#' Creates a comma separated CSV text file in which each row correspondes to an existing strain. Each row \code{i} contains a set of integers which identify the strain's allele at each existing loci. See the definition of 'allelic matrix' in \code{?runMANTIS}.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param fileout the name of the output CSV file.
exportAllelicMatrix <- function(data, fileout="default.filename.csv"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportAllelicMatrix")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportAllelicMatrix")
  }

  dataOut= extractAllelicMatrix(data)
  rownames(dataOut)= 1:nrow(dataOut)

  .writeCSVTS(dataOut, fileout)

}

#' Plot the sequences of the dominanting strains in time.
#' 
#' Makes 2 plots. Left subplot presents the simulated time series of the Y classes with the \code{extThreshold}
#' highlighted with a dashed black line. Right subplot presents the loci and alleles of the dominating strains
#' in time. In this plot, each locus is in a row and each column presents the alleles by colour (each possible
#' allele per locus has an unique colour). The number of available colours equals the maximum of available
#' alleles in all loci. Can create a PDF file.
#' 
#' @param data see \code{?plotY} for details.
#' @param extThreshold see \code{?extractDomVariant} or \code{?extractNoveltyVariant} for details.
#' @param epiStruc desired antigenic structure for the simulation. See \code{?runMANTIS} for details.
#' @param fileout see \code{?plotY} for details.
#' @param w see \code{?plotY} for details.
#' @param h see \code{?plotY} for details.
#' @param colours see \code{?plotY} for details.
#' @param xiObs see \code{?plotY} for details.
#' @param xfObs see \code{?plotY} for details.
#' @param mainLeft title for left subplot.
#' @param mainRight title for right subplot.
#' @param yylabLeft tile for top-left subplot y-axis.
#' @param yylabRight tile for top-right subplot y-axis.
#' @param xxlab see \code{?plotY} for details.
#'
plotSeqsOfDomVariant <- function(data, extThreshold, epiStruc, fileout=NA, w=7*1.5, h=1.5*2.5, colours=NULL, xiObs=0, xfObs=1, mainLeft="full time-series", mainRight="allelic info of dominant variants", yylabLeft="proportion infected", yylabRight="allele at loci L", xxlab="time"){

	  if(length(epiStruc)==0 | length(which(epiStruc<0))>0){
		stop("epiStruc has to be a 'collection' of integers bigger than zero. See '?runMANTIS")
	  }

	  if(length(epiStruc)==1){
		stop("the number of loci needs to be bigger or equal to 2. See '?runMANTIS")
	  }  

	.testPlotZYWParams(data, fileout, xfObs, xiObs)
	.testExtantThreshold(extThreshold,"plotSeqsOfDomVariant")
		
	nStrains<- ncol(data[[2]])/3
	X<- data[[1]]
	Y<- extractY(data) #infectious
		
	#build matrix that has the sequences of each dominant strain in time
	seqsOfDomVariant= extractSeqOfDomVariant(data, extThreshold=extThreshold)
	
	.plotSeqDomVar(X, Y, extThreshold, epiStruc, seqsOfDomVariant, nStrains, fileout, w, h, colours, xiObs, xfObs, mainLeft, mainRight, yylabLeft, yylabRight, xxlab)
	}	


#' Export the sequences of dominant strains in time.
#' 
#' Creates a comma separated CSV text file in which each row corresponds to a time step and information of the
#' dominant strain at the time. The information is essentially the sequence of the strain.
#' Each row \code{i} contains the time, the strain number and a set of integers which identify
#' the strain's allele at each existing loci (the allelic matrix). See the definition of 
#' 'allelic matrix' in \code{?runMANTIS}.
#' 
#' @param data the list as obtained from running the simulation. See \code{?runMANTIS} for details.
#' @param extThreshold the theoretical extinction threshold for the pathogen. See \code{?extractNoveltyVariant} for details. 
#' @param fileout the name of the output CSV file.
#'
exportSeqOfDomVariant <- function(data, extThreshold, fileout="default.filename.csv"){

  if(length(data)==0){
    stop("data seems to be empty. See '?exportSeqOfDomVariant")
  }

  if(!is.character(fileout)){
    stop("fileout has to be a set of characters. see ?exportSeqOfDomVariant")
  }

  .testExtantThreshold(extThreshold, "exportSeqOfDomVariant")
  
  dataOut= extractSeqOfDomVariant(data, extThreshold=extThreshold)

  .writeCSVTS(dataOut, fileout)

}
  
  
###################################################################
####### hidden, internal functions for MANTIS
  
.plotSeqDomVar <- function(X, Y, extThreshold, epiStruc, seqsOfDomVariant, nStrains, fileout, w, h, colours, xiObs, xfObs, mainLeft, mainRight, yylabLeft, yylabRight, xxlab){

	#default
	plotcols<- rainbow(nStrains, start=0.15)
	plotlwds<- rep(1, nStrains) 

	#manual colours or generate one per strain?
	if(!is.null(colours)){
		plotcols<- rep(colours,1+nStrains/length(colours))
	}

	if(!is.na(fileout))
		pdf(fileout, width=w, height=h, bg="white")
	
	rr= ((xiObs)*length(X)):((xfObs)*length(X)) #wanted zoom in range
	#print(rr)
	
	X= X[rr]
	minX= min(X)
	maxX= max(X)
	ymaxTL=max(Y[rr,], na.rm=TRUE)
	yminTL=min(Y[rr,], na.rm=TRUE) 
	ymaxTR=nStrains
	ymaxBL=nStrains
	ymaxBR=100

	layout(matrix(seq(1,2), ncol= 2, byrow=TRUE))
	par(mar=c(4, 4, 2, 1), cex=0.7)

	# display late Y dynamics in a plot
	plot(X, Y[rr,1],type="l",col=plotcols[1],ylim=c(yminTL,ymaxTL),ylab=yylabLeft,xlab=xxlab,main=mainLeft, lwd=plotlwds[1])
	for(i in 2:nStrains){ lines(X,Y[rr,i],type="l",col=plotcols[i], lwd=plotlwds[i]) }
	abline(h=extThreshold,lwd=1.5,lty=2)
	box(lwd=2)

	# display allelic info per loci
	#indWithData=which(!is.na(seqsOfDomVariant$domvariant[rr]))
	n.loci=length(epiStruc)
	rdcol=rainbow(n.loci)
	
	mmain="alleles at each locus in time"
	xxlab="time"
	yylab="locus"
	loci.image= as.matrix(seqsOfDomVariant[,3:(n.loci+2)])
	loci.colours= rainbow(length(min(loci.image):max(loci.image)))
	image(loci.image, col=loci.colours, xaxt='n', yaxt='n', ylab=yylab, xlab=xxlab, main=mmain)
	axis(2, at=(1:n.loci)-1 , labels=1:n.loci)
	axis(1, at=pretty(X)/max(X), labels=pretty(X))
	box(lwd=2)

	if(!is.na(fileout))  
		a=dev.off()

}
  
#### (ENDCODE_V3.0)
####################################################################################
#####################################################################################
  



#' Plot the infectious (Y) time-series of all strains in the system, from 2 simulations, side-by-side.
#' 
#' Make 2 plots for each simulation, one with the full time-series, another zooming into a portion of the simulation. Can create a PDF file.
#' 
#' @param data1 the list as obtained from running one simulation. See \code{?runMANTIS} for details.
#' @param data2 the list as obtained from running one simulation. See \code{?runMANTIS} for details.
#' @param fileout the desired filename for the resulting PDF plot, if not given (NA) the plot goes to screen
#' @param w the width of the PDF plot. 
#' @param h the height of the PDF plot. 
#' @param colours the set of colours to be used for the existing strains. If \code{length(colours)<nStrains}, colours are reused (\code{nStrains} is the number of strains in \code{data}). If not defined by the user, the \code{rainbow} collection is used. 
#' @param xiObs the starting proportion of time used to zoom into the time-series. For example \code{xiObs=0.5} will start zooming from the middle of the time-series.
#' @param xfObs the end proportion of time used to zoom into the time-series. 
#' @param mainLeft1 main title for the left plot (simulation 1). 
#' @param mainRight1 main title for the right plot (simulation 1). 
#' @param ymax1 numeric value for the maximum to be represented in the Y axis (simulation 1).
#' @param yylab1 title for the y-axis (simulation 1). 
#' @param xxlab1 title for the x-axis (simulation 1). 
#' @param mainLeft2 main title for the left plot (simulation 2). 
#' @param mainRight2 main title for the right plot (simulation 2). 
#' @param ymax2 numeric value for the maximum to be represented in the Y axis (simulation 2).
#' @param yylab2 title for the y-axis (simulation 2). 
#' @param xxlab2 title for the x-axis (simulation 2). 
#' @param markStrains list of strain IDs (numbers), used to highlight the given strains in the plot. The highlight will consist of an increase in the thickness of the lines and, when \code{length(colours)} is 2, the first colour is used for these strains and the second colour for the remaining. 
#' @param addLegend boolean flag whether to add a legend to the time series plot.
plot2Y <- function(data1, data2, fileout=NA, w=7, h=3, colours=NULL, xiObs=0.9, xfObs=1, markStrains=NULL, ymax=NULL,
                              mainLeft1="full time-series", mainRight1="zoomed-in time-series", yylab1="proportion infected", xxlab1="time",
                              mainLeft2="full time-series", mainRight2="zoomed-in time-series", yylab2="proportion infected", xxlab2="time",
                              addLegend=FALSE){

  .testPlotZYWParams(data1, fileout, xfObs, xiObs)   
  .testPlotZYWParams(data2, fileout, xfObs, xiObs)   

  nStrains1<- ncol(data1[[2]])/3
  X1<- data1[[1]]
  Y1<- extractY(data1) #infectious

  nStrains2<- ncol(data2[[2]])/3
  X2<- data2[[1]]
  Y2<- extractY(data2) #infectious

  if(!is.na(fileout)) pdf(fileout, width=w, height=h, bg="white")
  layout(matrix(seq(1,4), ncol= 2, byrow=TRUE))
  par(mar=c(4, 4, 2, 1), cex=0.7)

  .plotFullAndZoomInSeries(X1, Y1, nStrains1, colours, xiObs, xfObs, mainLeft1, mainRight1, yylab1, xxlab1, markStrains, ymax, legendThis=addLegend)
  .plotFullAndZoomInSeries(X2, Y2, nStrains2, colours, xiObs, xfObs, mainLeft2, mainRight2, yylab2, xxlab2, markStrains, ymax, legendThis=addLegend)

  if(!is.na(fileout))  a=dev.off()

}